

console.log("Hello Professor");

console.log("What is your favorite color?");

console.log("My favorite color is Lavender");



